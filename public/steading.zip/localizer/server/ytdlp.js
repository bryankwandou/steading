/**
 * The only module in this project that spawns a process.
 *
 * Every argument list is built here from validated inputs and passed to execFile/spawn
 * as an array -- there is no shell, no string concatenation, and therefore no shell
 * quoting to get wrong. Routes call these functions; routes never import child_process.
 */

import { spawn, execFile, execFileSync } from 'node:child_process';
import { readdir } from 'node:fs/promises';
import { join } from 'node:path';
import { config } from './config.js';
import { createLineSplitter, parseLine } from './lib/progress.js';
import { ERR, coded } from './lib/errors.js';

/** Fixed output basename: metadata titles become the *download* name, never a path. */
const OUTPUT_BASENAME = 'media';

class MissingBinaryError extends Error {
  constructor(name) {
    super(`${name} is not installed.`);
    this.code = ERR.NO_BINARY;
    this.detail = name;
  }
}

function requireYtdlp() {
  const bin = config.ytdlp;
  if (!bin) throw new MissingBinaryError('yt-dlp');
  return bin;
}

/** Args shared by every invocation. */
function baseArgs() {
  const args = [
    '--no-playlist',        // a link inside a playlist means "this one video"
    '--no-warnings',
    '--no-color',
    '--no-mtime',
    '--retries', '3',
    '--socket-timeout', '15',
  ];
  if (config.ffmpeg) args.push('--ffmpeg-location', config.ffmpeg);
  return args;
}

/** @returns {string[]} argv for a metadata-only probe. Exported for tests. */
export function buildInfoArgs(url) {
  return [...baseArgs(), '--dump-single-json', '--skip-download', '--', url];
}

/**
 * @returns {string[]} argv for an actual download. Exported for tests -- this is the
 * function most likely to be edited later, and the format selector is easy to get
 * subtly wrong.
 */
export function buildDownloadArgs({ url, format, quality = 'best', dir }) {
  const args = [
    ...baseArgs(),
    '--newline',
    // Fixed, space-free template consumed by lib/progress.js.
    '--progress-template',
    'LZPROG %(progress.downloaded_bytes)s %(progress.total_bytes_estimate)s %(progress.speed)s %(progress.eta)s %(progress.fragment_index)s %(progress.fragment_count)s',
    '--paths', dir,
    '--output', `${OUTPUT_BASENAME}.%(ext)s`,
  ];

  if (format === 'mp3') {
    args.push('--extract-audio', '--audio-format', 'mp3', '--audio-quality', '0');
  } else {
    // Prefer an mp4/m4a pair so the merge is a remux rather than a re-encode; fall back
    // progressively so an odd source still produces something playable.
    const cap = quality === 'best' ? '' : `[height<=${quality}]`;
    args.push(
      '--format',
      `bv*${cap}[ext=mp4]+ba[ext=m4a]/bv*${cap}+ba/b${cap}/bv*+ba/b`,
      '--merge-output-format', 'mp4',
    );
  }

  args.push('--', url);
  return args;
}

/** Pull the fields the UI actually renders out of yt-dlp's very large JSON blob. */
export function normalizeInfo(raw) {
  const heights = new Set();
  for (const f of raw?.formats ?? []) {
    if (f?.vcodec && f.vcodec !== 'none' && Number.isFinite(f.height)) heights.add(f.height);
  }

  const offered = ['1080', '720', '480', '360'].filter((q) => [...heights].some((h) => h >= Number(q)));

  return {
    // null, not a placeholder string: the client owns the "untitled" wording.
    title: (typeof raw?.title === 'string' && raw.title.trim()) || null,
    uploader: raw?.uploader || raw?.channel || raw?.uploader_id || null,
    duration: Number.isFinite(raw?.duration) ? Math.round(raw.duration) : null,
    thumbnail: typeof raw?.thumbnail === 'string' && /^https?:\/\//.test(raw.thumbnail) ? raw.thumbnail : null,
    extractor: raw?.extractor_key || raw?.extractor || null,
    isLive: Boolean(raw?.is_live),
    qualities: ['best', ...offered],
  };
}

/**
 * Turn yt-dlp's stderr into a stable error code plus the raw line as `detail`.
 *
 * The raw line is kept because there is a long tail of extractor-specific failures no
 * classifier will ever cover, and a developer-readable line beats a shrug. It is shown
 * only under a translated heading, never as the whole message.
 *
 * @returns {{code: string, detail: string|null}}
 */
export function classifyError(stderr) {
  const line = String(stderr || '')
    .split(/\r?\n/)
    .map((s) => s.trim())
    .filter((s) => /^ERROR/i.test(s))
    .pop() || String(stderr || '').trim().split(/\r?\n/).pop() || '';

  const msg = line.replace(/^ERROR[:\s]+/i, '').replace(/^\[[^\]]+\]\s*/, '').trim();

  // Order matters: "not available in your country" is geo, not a missing video, so the
  // region test runs before the generic unavailable test.
  if (/geo|country|region|not available in/i.test(msg)) return { code: ERR.GEO_BLOCKED, detail: msg };
  if (/private|login required|sign in|members-only|cookies|age.?restrict/i.test(msg)) {
    return { code: ERR.PRIVATE_CONTENT, detail: msg };
  }
  if (/unavailable|removed|deleted|404|not found|does not exist/i.test(msg)) {
    return { code: ERR.CONTENT_GONE, detail: msg };
  }
  if (/live event|is live|live stream/i.test(msg)) return { code: ERR.IS_LIVE, detail: msg };
  if (/timed out|timeout|network|resolve host|connection|unreachable|temporary failure/i.test(msg)) {
    return { code: ERR.NETWORK, detail: msg };
  }
  return { code: ERR.DOWNLOAD_FAILED, detail: msg || null };
}

/**
 * Metadata only -- no bytes of media are fetched.
 * @returns {Promise<object>} normalized info
 */
export function fetchInfo(url) {
  const bin = requireYtdlp();
  return new Promise((resolvePromise, rejectPromise) => {
    execFile(
      bin,
      buildInfoArgs(url),
      { timeout: config.infoTimeoutMs, maxBuffer: 32 * 1024 * 1024, windowsHide: true },
      (err, stdout, stderr) => {
        if (err) {
          if (err.killed) return rejectPromise(coded(ERR.INFO_TIMEOUT));
          const { code, detail } = classifyError(stderr);
          return rejectPromise(coded(code, { detail }));
        }
        try {
          resolvePromise(normalizeInfo(JSON.parse(stdout)));
        } catch {
          rejectPromise(coded(ERR.INFO_UNREADABLE));
        }
      },
    );
  });
}

/**
 * Start a download.
 *
 * Returns a handle rather than a bare promise so jobs.js can kill it. The caller owns
 * `dir` and is responsible for purging it -- this function never deletes anything, so
 * there is exactly one place (jobs.js) where cleanup can be reasoned about.
 *
 * @returns {{child: import('node:child_process').ChildProcess, done: Promise<{file: string}>}}
 */
export function startDownload({ url, format, quality, dir, onEvent }) {
  const bin = requireYtdlp();
  const child = spawn(bin, buildDownloadArgs({ url, format, quality, dir }), {
    windowsHide: true,
    stdio: ['ignore', 'pipe', 'pipe'],
    // Own process group on POSIX, so killTree can signal yt-dlp *and* the ffmpeg it
    // spawns. Without this, killing yt-dlp leaves ffmpeg holding the temp files open.
    detached: process.platform !== 'win32',
  });

  let stderrTail = '';
  let sawError = null;

  const emit = (event) => { try { onEvent?.(event); } catch { /* listener errors are not ours */ } };

  const splitter = createLineSplitter((line) => {
    const parsed = parseLine(line);
    if (!parsed) return;
    if (parsed.type === 'error') sawError = parsed.message;
    if (parsed.type === 'progress' || parsed.type === 'phase') emit(parsed);
  });

  child.stdout.setEncoding('utf8');
  child.stdout.on('data', (chunk) => splitter.push(chunk));

  child.stderr.setEncoding('utf8');
  child.stderr.on('data', (chunk) => {
    stderrTail = (stderrTail + chunk).slice(-4000);
    splitter.push(chunk);
  });

  const done = new Promise((resolvePromise, rejectPromise) => {
    const timer = setTimeout(() => {
      child.kill('SIGKILL');
      rejectPromise(coded(ERR.DOWNLOAD_TIMEOUT));
    }, config.downloadTimeoutMs);

    child.on('error', (err) => {
      clearTimeout(timer);
      rejectPromise(err.code === 'ENOENT' ? new MissingBinaryError('yt-dlp') : err);
    });

    child.on('close', async (code, signal) => {
      clearTimeout(timer);
      splitter.flush();

      if (signal) return rejectPromise(coded(ERR.CANCELED));
      if (code !== 0) {
        const classified = classifyError(sawError || stderrTail);
        return rejectPromise(coded(classified.code, { detail: classified.detail }));
      }

      try {
        resolvePromise({ file: await findOutputFile(dir, format) });
      } catch (err) {
        rejectPromise(err);
      }
    });
  });

  return { child, done };
}

/**
 * Locate the finished file. yt-dlp writes fragments and intermediate streams next to
 * the result (media.f137.mp4, media.temp.mp4, .part files), so we take the exact
 * `media.<ext>` match first and only then fall back to the largest plausible file.
 */
export async function findOutputFile(dir, format) {
  const entries = await readdir(dir, { withFileTypes: true });
  const files = entries.filter((e) => e.isFile()).map((e) => e.name);

  const exact = files.find((n) => n === `${OUTPUT_BASENAME}.${format}`);
  if (exact) return join(dir, exact);

  const candidates = files.filter(
    (n) => n.startsWith(`${OUTPUT_BASENAME}.`)
      && !n.endsWith('.part')
      && !n.endsWith('.ytdl')
      && !/\.f\d+\./.test(n)
      && !n.includes('.temp.'),
  );
  if (candidates.length === 1) return join(dir, candidates[0]);
  if (candidates.length > 1) {
    // Deterministic: shortest name wins, i.e. media.mp4 over media.something.mp4.
    candidates.sort((a, b) => a.length - b.length || a.localeCompare(b));
    return join(dir, candidates[0]);
  }

  throw coded(ERR.NO_OUTPUT_FILE);
}

/**
 * Kill a download and everything it spawned, then wait for the OS to actually reap it.
 *
 * This exists because of a bug found in testing: cancelling a job removed the temp
 * folder while yt-dlp (and the ffmpeg it had started) were still writing, so the
 * directory reappeared moments later and leaked. Killing the tree is only half the
 * fix -- the caller must also wait for the exit before deleting anything, which is why
 * this returns a promise.
 *
 * @returns {Promise<void>} resolves once the process is gone, or after a short cap.
 */
export function killTree(child) {
  if (!child || child.exitCode !== null || child.signalCode !== null) return Promise.resolve();

  return new Promise((resolvePromise) => {
    let settled = false;
    const finish = () => {
      if (settled) return;
      settled = true;
      clearTimeout(cap);
      resolvePromise();
    };

    child.once('exit', finish);
    child.once('close', finish);

    // Never let cleanup hang on a wedged process; the purge retries cover the rest.
    const cap = setTimeout(finish, 4000);
    cap.unref?.();

    try {
      if (process.platform === 'win32') {
        // Windows has no process groups we can signal; taskkill /T walks the tree.
        execFile('taskkill', ['/pid', String(child.pid), '/T', '/F'], { windowsHide: true }, () => {});
      } else {
        // Negative pid = the whole process group created by detached: true.
        try { process.kill(-child.pid, 'SIGKILL'); } catch { child.kill('SIGKILL'); }
      }
    } catch {
      try { child.kill('SIGKILL'); } catch { /* already gone */ }
    }
  });
}

/**
 * Synchronous tree kill, for exit handlers only -- once the event loop is winding down
 * there is no chance for the async version to finish.
 */
export function killTreeSync(child) {
  if (!child || child.exitCode !== null) return;
  try {
    if (process.platform === 'win32') {
      execFileSync('taskkill', ['/pid', String(child.pid), '/T', '/F'], { stdio: 'ignore', windowsHide: true });
    } else {
      try { process.kill(-child.pid, 'SIGKILL'); } catch { child.kill('SIGKILL'); }
    }
  } catch {
    /* exiting anyway */
  }
}

/**
 * Used by check-deps.js and /api/health.
 * ffmpeg wants a single-dash `-version` and prints its banner to stderr, so the flag is
 * a parameter and both streams are considered.
 *
 * Asking yt-dlp its version is not cheap -- it loads its whole extractor tree first,
 * which measured 17 to 60 seconds on a low-powered laptop. The old ten second window
 * expired long before that, the answer came back null, and the status line reported
 * "yt-dlp is not installed" at someone who had it installed all along. So the window is
 * generous now, and an answer that does arrive is kept: a binary cannot change version
 * while the process that asked is still running.
 *
 * Only successes are cached. A timeout leaves the slot empty so a later call can try
 * again, rather than making one slow moment permanent.
 */
const versionCache = new Map();

export function probeVersion(bin, flag = '--version') {
  return new Promise((resolvePromise) => {
    if (!bin) return resolvePromise(null);
    if (versionCache.has(bin)) return resolvePromise(versionCache.get(bin));

    // execFile can throw before it ever runs -- an unspawnable path, or a .cmd/.bat,
    // which Node refuses without a shell. Left uncaught that rejects this promise and
    // takes down `npm run check` with a stack trace, in front of the one person who
    // most needs a plain sentence about what is missing. Unspawnable is just absent.
    try {
      execFile(bin, [flag], { timeout: 90_000, windowsHide: true }, (err, stdout, stderr) => {
        const first = String(stdout || stderr || '').trim().split(/\r?\n/)[0]?.trim();
        // ffmpeg exits non-zero on some builds while still printing a valid banner.
        const version = first && /\d/.test(first) ? first : (err ? null : first || null);
        if (version) versionCache.set(bin, version);
        resolvePromise(version);
      });
    } catch {
      resolvePromise(null);
    }
  });
}

/**
 * Start both probes without waiting for them, so the first page load finds the answers
 * already cached instead of paying the wait itself.
 */
export function warmVersions() {
  probeVersion(config.ytdlp).catch(() => {});
  probeVersion(config.ffmpeg, '-version').catch(() => {});
}

export { MissingBinaryError, OUTPUT_BASENAME };
