# Localizer

> Fast. Seamless. 100% Local.

Video & audio downloader (YouTube, TikTok, Instagram, Facebook) that runs entirely on
the user's own machine or phone. No hosting, no accounts, no telemetry, no cloud round
trip. The frontend is a PWA installable to the home screen; the backend is a
zero-dependency Node HTTP server that drives `yt-dlp` and `ffmpeg`.

## Non-negotiables

1. **Zero npm dependencies.** `package.json` has an empty `dependencies` block and it
   stays that way. `npm install` on Termux is slow and fragile; a folder you can `node
   server/index.js` straight out of a `git clone` is far more robust. External tooling
   (`yt-dlp`, `ffmpeg`) ships as platform binaries, not npm packages.
2. **No build step.** Plain HTML + CSS + ES modules. Edit, refresh, done. App shell
   budget: under 70 KB uncompressed, excluding icons (currently ~61 KB, roughly a third
   of it comments). The number that actually matters is that it does **not grow with
   the language count** — only English and Indonesian are inline; the other 22
   dictionaries are 113 KB that never load unless someone picks one.
3. **One spawn site.** Only `server/ytdlp.js` may call `child_process`. Routes never
   touch it. This keeps the entire command-injection surface auditable in one file.
4. **Every temp file is owned by a job, and every job cleans up.** See the cleanup
   contract below — it is a hard requirement, not a nicety.
5. **The server never sends prose.** Every failure crosses the wire as a stable code
   from `server/lib/errors.js`; the client owns the wording. Adding a language must
   never require touching server code.
6. **No component hard-codes a colour.** Every colour is a token defined in both themes.
   A component that reaches for a literal is a dark-mode bug waiting to happen.

## Tech stack

| Layer     | Choice                                                        |
| --------- | ------------------------------------------------------------- |
| Backend   | Node.js >= 18, `node:http` / `node:child_process` / `node:fs`  |
| Frontend  | HTML + hand-written CSS + Vanilla JS (ES modules)              |
| Transport | JSON over `fetch`, live progress over Server-Sent Events       |
| External  | `yt-dlp` (extraction/download), `ffmpeg` (merge, MP3 encode)   |

## Folder layout

```
localizer/
├── CLAUDE.md · README.md · package.json      dependencies: {}
├── server/
│   ├── index.js        HTTP routing, SSE, file streaming
│   ├── config.js       port, host, binary resolution, limits
│   ├── static.js       public/ server + MIME + cache headers
│   ├── ytdlp.js        THE ONLY module that spawns processes
│   └── lib/
│       ├── errors.js     THE error-code table (server side of i18n)
│       ├── validate.js   URL allowlist + format/quality validation
│       ├── progress.js   yt-dlp stdout -> structured progress events
│       ├── jobs.js       job registry, lifecycle, SSE fan-out
│       └── cleanup.js    tmp dir removal, sweeper, exit hooks
├── public/
│   ├── index.html · manifest.json · sw.js
│   ├── css/style.css                  light + dark tokens, one source of colour
│   ├── js/app.js · js/api.js
│   ├── js/i18n.js       dictionaries (en + id inline), lookup, language switching
│   ├── js/theme.js      light/dark/system, persistence, crossfade
│   ├── js/boot-theme.js blocking pre-paint theme guard (no inline script under CSP)
│   ├── i18n/<code>.json 22 lazy-loaded dictionaries
│   └── icons/
├── scripts/  check-deps.js · make-icons.js · setup-termux.sh · setup-windows.ps1
└── tmp/      per-job scratch space, always transient
```

## How the local backend works

The server binds to `127.0.0.1:3000`. On a phone this runs inside Termux and you open
`http://localhost:3000` in Chrome on that same device. This matters: `localhost` counts
as a **secure context**, so Service Workers and "Add to Home Screen" work fully without
HTTPS or certificates.

Request flow:

1. Paste URL -> `POST /api/info` -> `yt-dlp -J` fetches **metadata only**, nothing is
   downloaded yet. Title, thumbnail, duration and available qualities come back.
2. Choose MP4 or MP3 -> `POST /api/jobs` -> the server spawns `yt-dlp`, writing into
   `tmp/<jobId>/`.
3. `GET /api/jobs/:id/events` (SSE) streams real percentage, speed and ETA, including
   the ffmpeg merge / MP3 encode phase.
4. `GET /api/jobs/:id/file` streams the finished file as an attachment; the browser
   drops it in the device's Downloads folder, then the temp directory is purged.

**Why two phases instead of piping yt-dlp straight into the HTTP response:** merging
video+audio and encoding MP3 both need seekable output, which a pipe cannot provide.
A pipe also means no `Content-Length`, so a mobile browser shows no download progress.
The two-phase design keeps both. Nothing accumulates server-side either way.

## Cleanup contract

Temp directories are the one thing that can silently eat a phone's storage, so the
rules are explicit:

- **Success** — the temp dir is removed right after the file finishes streaming.
- **Client disappears mid-download** — when the SSE stream closes and the job is still
  running, a 15 s grace timer starts (survives a flaky-network reconnect). If nobody
  reattaches, the child process is killed and the temp dir is removed.
- **Error / cancel** — the child is killed with SIGKILL and the temp dir is removed in
  the same `finally` path. There is exactly one purge function; every terminal state
  routes through it.
- **Idle completed job** — a finished file nobody fetched is purged after 10 minutes.
- **Startup sweep** — on boot, `tmp/` is wiped of anything left by a previous run
  (power loss, `kill -9`, Termux swipe-away).
- **Exit hooks** — `SIGINT`, `SIGTERM` and `beforeExit` purge all live jobs
  synchronously.

Invariant to preserve when editing: **no code path may create a directory under `tmp/`
without registering it with a job**, because the sweeper and exit hooks only know about
registered jobs plus whole-directory wipes at boot.

## Localization

24 languages. English and Indonesian are compiled into `public/js/i18n.js`; the other
22 sit in `public/i18n/<code>.json` and are fetched the first time they are chosen, so
the app shell stays small on a phone. A missing key falls back to English rather than
rendering a raw identifier.

The important half is on the server: **no user-facing sentence exists in server code.**
Every failure is a code from `server/lib/errors.js` (`private_content`, `geo_blocked`,
`too_many_jobs`), sent as `{ code, error, detail }` where `error` is only an English
fallback for non-Localizer clients and `detail` is optional raw context such as the
yt-dlp line. `classifyError()` in ytdlp.js maps stderr to those codes.

Consequences to preserve:

- Adding a language is one JSON file plus one row in `LANGUAGES`. No server change.
- Anything rendered from state must be re-renderable. The UI stores messages as
  `{key, vars}`, not as finished strings, so switching language mid-error updates the
  text that is already on screen. `repaintLanguage()` in app.js is the single place
  that replays all such state.
- `tests/i18n.test.js` enforces the invariants a reviewer cannot check by eye: key
  parity across all 24 dictionaries, identical `{placeholder}` sets, no prose left in
  English, and an entry for every code in `ERR`.
- Arabic and Persian set `dir="rtl"` on `<html>`. The layout is flex-based so it
  mirrors for free; only physically-offset items have RTL rules in the stylesheet.

## Theming

Three states, two stored values: `light`, `dark`, or no stored value at all, which
*is* the "follow the system" state. That is why absence is meaningful and must not be
normalized away — the OS switching at sunset should keep working until the user makes
an explicit choice.

- `public/js/boot-theme.js` is a blocking classic script in `<head>`. It stamps
  `data-theme` before the stylesheet paints, so a dark-mode phone never flashes white.
  It is a separate file rather than inline script because of the CSP.
- Colour transitions are enabled **only** during the 200 ms crossfade, via the
  `.theme-shifting` class. Leaving them on globally makes every unrelated hover lag by
  the same 200 ms, which is what a "janky" theme toggle usually is.
- `[hidden] { display: none !important; }` is load-bearing: the UA rule for `[hidden]`
  loses to any class that sets a display, and `.card` is `display: flex`.

## Reaching the server from outside

`npm run share` puts the server behind a Cloudflare quick tunnel. Two things had to
change for that to work, and both are worth keeping straight.

**PUBLIC_HOST.** `hostAllowed()` rejects any Host that is not a loopback name, which is
the DNS-rebinding defence and must stay. A tunnel arrives with a public Host, so
`config.publicHosts` lists extra hostnames that are also accepted. It is empty by
default and `scripts/share.js` sets it to the one hostname cloudflared just printed —
never a wildcard. A plain `npm start` is unchanged.

**SSE is not reliable through proxies.** Cloudflare buffers `text/event-stream`, so the
browser receives nothing and the progress bar sits frozen while the download actually
runs. `api.watch()` therefore runs a watchdog: if no frame arrives for five seconds it
abandons the stream and polls `GET /api/jobs/:id` instead.

That fallback broke the cleanup contract the first time it was written, and the fix
matters. Dropping the SSE stream is exactly the signal `subscribe()` uses to decide the
browser is gone, so the job was reclaimed mid-download and the user was told "the
browser disconnected". `touchJob()` closes that hole: every status read pushes the
abandon deadline back, so a polling client counts as present. If you change either side
of this, keep the two tests named around polling in tests/jobs.test.js passing.

## Security

The threat model is a hostile page in another tab on the same device, not a remote
attacker — the server binds to loopback.

- **Allowlist before spawn.** Only the four supported platforms reach yt-dlp.
- **No shell, ever.** Array argv only, built in one file, always `--` before the URL.
- **Host check, not just Origin.** A hostile domain can resolve to 127.0.0.1 and pass an
  Origin check because the origin is genuinely its own. It cannot forge `Host`, so
  `hostAllowed()` rejects anything not addressed to a loopback name. This is the
  defence against DNS rebinding and it must not be removed.
- **CSP** on HTML responses: `script-src 'self'`, no inline script, `frame-ancestors
  'none'`, `form-action 'none'`. `img-src` allows `https:` because thumbnails come
  from platform CDNs; an `<img>` cannot execute.
- **Titles are untrusted input.** They arrive from a remote site and end up in a
  `Content-Disposition` header and the user's filesystem, so `safeFilename()` strips
  path separators, Windows-reserved characters, control characters, and device names.
- **Interpolation is textContent only.** `t()` results are assigned to `textContent`,
  never `innerHTML`, so a hostile video title cannot become markup.

## Design direction

A single blue accent spent sparingly — primary button, progress line, focus ring,
nothing else. 10 px radii, 1 px borders instead of heavy shadows, progress as a 4 px
hairline rather than a fat pill, hand-written 1.5-stroke SVG icons. Single column,
`max-width: 560px`, mobile-first, 44 px touch targets, notch-safe insets.

Light is white canvas with `#0D1526` ink and a `#1B6EF3` accent. Dark is blue-tinted
slate (`#0B1220`), never pure black, with the accent lifted to `#5B9DFF` so it still
reads as the accent against a dark ground. Every pairing meets WCAG AA; `--ink-faint`
is deliberately pinned at the faintest tone that still passes.

The two pieces of motion that earn their keep: the segmented control's thumb slides
between MP4 and MP3, and cards rise 5 px on entry. Both respect
`prefers-reduced-motion`.

Explicitly avoided, because they read as template output: gradient hero sections,
`rounded-3xl` cards with wide shadows, sparkle badges, emoji in UI copy.

## Testing

`npm test` runs `node --test --experimental-test-module-mocks tests/*.test.js` and
covers the modules with real logic: URL validation, the progress parser, the yt-dlp
argument builder, the job lifecycle and its cleanup contract (yt-dlp mocked), and
translation integrity across all 24 dictionaries.

Not covered by unit tests, and therefore verified by hand against a live URL whenever
this area changes: an actual MP4 and MP3 download end to end, and the two cleanup paths
that involve a real child process (cancel mid-download, and the browser disconnecting).
Both leave `tmp/` empty; that is the assertion that matters.

## Scope

MVP only. Deliberately left out: playlists, download history, subtitles, batch queues.
The app stays small; these can land later without reshaping anything above.
