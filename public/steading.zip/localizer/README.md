# Localizer

**Fast. Seamless. 100% Local.**

Pengunduh video dan audio (YouTube, TikTok, Instagram, Facebook) yang berjalan
sepenuhnya di perangkat Anda sendiri. Tidak ada server internet, tidak ada akun, tidak
ada data yang keluar dari perangkat. Frontend-nya PWA — bisa dipasang ke home screen
seperti aplikasi biasa.

Nol dependensi npm. Tanpa build step. `git clone`, pasang yt-dlp, jalankan.

Antarmukanya punya **tema terang dan gelap** (mengikuti sistem, bisa ditimpa manual)
dan tersedia dalam **24 bahasa**, dengan Indonesia dan Inggris sebagai bahasa utama.

## Pasang di HP (Termux)

1. Pasang **Termux** dari [F-Droid](https://f-droid.org/packages/com.termux/)
   (versi Play Store sudah tidak diperbarui).
2. Di Termux:

```bash
pkg install -y git
git clone <repo-anda> localizer && cd localizer
bash scripts/setup-termux.sh
```

3. Jalankan server:

```bash
npm start
```

4. Buka **Chrome di HP yang sama** ke `http://localhost:3000`.
5. Menu Chrome → **Add to Home screen**. Selesai — sekarang ada ikon Localizer di
   layar utama.

Agar Android tidak mematikan Termux di latar belakang, jalankan sekali:

```bash
termux-wake-lock
```

## Pasang di PC

**Windows**

```bash
powershell -ExecutionPolicy Bypass -File scripts\setup-windows.ps1
```

**macOS / Linux**

```bash
brew install yt-dlp ffmpeg
```

Atau di Debian/Ubuntu: `pipx install yt-dlp && sudo apt install ffmpeg`.

Lalu:

```bash
npm run check
npm start
```

Buka `http://localhost:3000`.

> Alternatif tanpa memasang apa pun secara global: letakkan `yt-dlp` (atau
> `yt-dlp.exe`) di folder `bin/`. Localizer memeriksa folder itu lebih dulu sebelum
> PATH.

## Cara pakai

1. Tempel tautan, tekan **Cek tautan**.
2. Muncul judul, thumbnail, durasi. Pilih **Video MP4** atau **Audio MP3**, lalu
   kualitas untuk video.
3. Tekan **Unduh**. Progress bar menampilkan persentase, kecepatan, dan sisa waktu
   yang sebenarnya — termasuk tahap penggabungan video/audio.
4. Begitu selesai, berkas langsung tersimpan ke folder Download perangkat, dan salinan
   sementara di server dihapus.

**Bonus:** karena manifest mendaftarkan Localizer sebagai share target, Anda bisa
menekan **Bagikan → Localizer** langsung dari aplikasi YouTube atau TikTok. Tautannya
otomatis terisi dan langsung diperiksa.

## Membuktikan ke orang lain tanpa memasang apa pun

Kalau seseorang harus memverifikasi aplikasi ini bekerja tapi tidak bisa memasangnya —
penguji, dosen, juri — jalankan:

```bash
npm run share
```

Perintah itu membuka terowongan Cloudflare dan mencetak satu URL publik. Siapa pun yang
membuka URL itu memakai Localizer yang sungguhan: unduhan asli, berkas asli, berjalan di
mesin Anda. Butuh `cloudflared` (`winget install Cloudflare.cloudflared` di Windows,
`pkg install cloudflared` di Termux).

Tiga hal yang perlu Anda sadari sebelum memakainya:

- **URL itu publik selama menyala.** Ia pengunduh yang bisa dipakai siapa saja yang
  memegang tautannya, memakai koneksi dan penyimpanan Anda. Tekan Ctrl-C begitu selesai.
- **Alamatnya berganti setiap kali dijalankan.** Terowongan cepat memberi nama acak
  baru, jadi bagikan URL-nya setelah menyalakan, bukan sebelumnya.
- **Hanya hostname itu yang diizinkan.** Proteksi DNS rebinding tetap berlaku; server
  masih menolak Host lain, termasuk yang mencoba menyamar.

Kenapa ini yang dipakai dan bukan hosting biasa: keempat platform yang didukung
memblokir alamat IP milik penyedia hosting. Diuji langsung dari Vercel, TikTok
menjawabnya harfiah — "Your IP address is blocked from accessing this post". Dari
koneksi rumah Anda tidak ada masalah itu, dan terowongan membuat koneksi rumah itulah
yang dipakai.

## Tema dan bahasa

Dua tombol di pojok kanan atas.

**Tema** mengikuti setelan sistem sampai Anda menekannya sekali; setelah itu pilihan
Anda yang menang dan tersimpan. Warnanya berganti dengan transisi 200 ms, dan tema
yang benar sudah terpasang sebelum halaman digambar — tidak ada kedipan putih saat
membuka aplikasi dalam mode gelap.

**Bahasa** terisi otomatis dari bahasa peramban, lalu bisa diganti kapan saja. Bahasa
Indonesia dan Inggris ikut di dalam app shell; 22 bahasa lain diambil sekali saat
dipilih, jadi ukuran shell tetap kecil. Bahasa Arab dan Persia otomatis beralih ke tata
letak kanan-ke-kiri.

| Bahasa yang tersedia |
| -------------------- |
| Indonesia, English, Melayu, العربية, বাংলা, Deutsch, Español, فارسی, Filipino, Français, हिन्दी, Italiano, 日本語, 한국어, Nederlands, Polski, Português, Русский, ไทย, Türkçe, Українська, Tiếng Việt, 简体中文, 繁體中文 |

Server tidak pernah mengirim kalimat siap tampil. Ia mengirim **kode galat** seperti
`private_content`, dan sisi klien yang memilih kata-katanya. Menambah bahasa baru cukup
dengan menaruh satu berkas di `public/i18n/`; kode server tidak perlu disentuh sama
sekali.

## Perintah

| Perintah        | Fungsi                                      |
| --------------- | ------------------------------------------- |
| `npm start`     | menjalankan server di `127.0.0.1:3000`      |
| `npm run share` | sama, plus URL publik sementara lewat terowongan |
| `npm run check` | memeriksa yt-dlp, ffmpeg, dan versi Node    |
| `npm test`      | menjalankan unit test                       |
| `npm run icons` | membuat ulang ikon PWA                      |

Ganti port: `PORT=3001 npm start`.

## Cara kerjanya

```
Browser  ──POST /api/info──▶  yt-dlp -J          (metadata saja, belum mengunduh)
         ──POST /api/jobs──▶  yt-dlp → tmp/<id>/ (unduhan sungguhan dimulai)
         ◀──SSE /events────   progres nyata: persen, kecepatan, ETA, tahap ffmpeg
         ──GET  /file──────▶  berkas di-stream sebagai attachment, lalu tmp/ dihapus
```

Dua fase, bukan satu pipa langsung, karena penggabungan video+audio dan encoding MP3
sama-sama butuh berkas yang bisa di-seek — pipa tidak bisa. Efek sampingnya justru
bagus: ada `Content-Length`, jadi browser HP menampilkan progress unduhan yang benar.

Penjelasan arsitektur lengkap, termasuk kontrak pembersihan berkas sementara, ada di
[CLAUDE.md](CLAUDE.md).

## Keamanan

Localizer mengikat diri ke `127.0.0.1` dan tidak pernah membuka diri ke jaringan, tapi
sebuah halaman jahat di tab lain tetap bisa mencoba menghubunginya. Yang menahannya:

- **Daftar putih situs.** yt-dlp hanya menerima host YouTube, TikTok, Instagram, dan
  Facebook. Selain itu ditolak sebelum ada proses yang dijalankan.
- **Tanpa shell.** Semua argumen disusun sebagai array di satu berkas (`server/ytdlp.js`)
  dan selalu ditutup `--` sebelum URL, jadi tautan tidak pernah bisa menyamar jadi flag.
- **Cek Host, bukan cuma Origin.** Situs jahat bisa mengarahkan domainnya sendiri ke
  127.0.0.1 (DNS rebinding) sehingga lolos pemeriksaan Origin. Header `Host` tidak bisa
  dipalsukan seperti itu, dan permintaan yang tidak dialamatkan ke nama loopback ditolak.
- **CSP ketat.** Halaman hanya boleh memuat skrip dan gaya dari dirinya sendiri, tidak
  bisa dibingkai, dan tidak punya skrip inline sama sekali.
- **Nama berkas dibersihkan.** Judul datang dari situs luar, jadi ia dibersihkan dari
  pemisah path, karakter terlarang Windows, dan nama perangkat seperti `CON`.
- **Batas ukuran permintaan** 8 KB, dan maksimal dua unduhan berjalan bersamaan.

## Kalau ada masalah

**"yt-dlp belum terpasang"** — jalankan `npm run check`, ikuti perintah pemasangan yang
ditampilkan untuk platform Anda.

**MP3 gagal, atau video tanpa suara** — ffmpeg belum ada. `pkg install ffmpeg` di
Termux, `winget install Gyan.FFmpeg` di Windows.

**"Konten ini privat atau butuh login"** — Localizer hanya mengambil konten publik.
Postingan privat memang tidak bisa diunduh.

**Situs berubah dan unduhan mulai gagal** — YouTube dan TikTok rutin mengubah cara
kerja mereka. Perbarui yt-dlp: `pip install -U yt-dlp` (Termux) atau
`yt-dlp -U` (biner mandiri). Ini penyebab paling sering dari error 403.

**Port 3000 dipakai aplikasi lain** — `PORT=3001 npm start`.

## Catatan penggunaan

Unduh hanya konten yang Anda berhak simpan — karya sendiri, materi berlisensi bebas,
atau hal-hal yang diizinkan oleh ketentuan layanan platform terkait. Alat ini berjalan
lokal di perangkat Anda; tanggung jawab atas apa yang diunduh ada pada Anda.
