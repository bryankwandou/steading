import test from 'node:test';
import assert from 'node:assert/strict';
import {
  validateUrl, validateFormat, validateQuality, validateJobId, safeFilename,
} from '../server/lib/validate.js';

test('accepts the four supported platforms', () => {
  const cases = [
    ['https://www.youtube.com/watch?v=dQw4w9WgXcQ', 'youtube'],
    ['https://youtu.be/dQw4w9WgXcQ', 'youtube'],
    ['https://music.youtube.com/watch?v=abc', 'youtube'],
    ['https://www.tiktok.com/@user/video/123', 'tiktok'],
    ['https://vt.tiktok.com/ZSabc/', 'tiktok'],
    ['https://www.instagram.com/reel/Cabc/', 'instagram'],
    ['https://www.facebook.com/watch/?v=123', 'facebook'],
    ['https://fb.watch/abc/', 'facebook'],
  ];
  for (const [url, platform] of cases) {
    const r = validateUrl(url);
    assert.equal(r.ok, true, `expected ${url} to pass`);
    assert.equal(r.platform, platform);
  }
});

test('assumes https for a scheme-less paste', () => {
  const r = validateUrl('youtube.com/watch?v=abc');
  assert.equal(r.ok, true);
  assert.match(r.url, /^https:\/\//);
});

test('rejects unsupported hosts', () => {
  for (const url of ['https://example.com/v/1', 'https://vimeo.com/123', 'https://notyoutube.com/x']) {
    assert.equal(validateUrl(url).ok, false, `expected ${url} to fail`);
  }
});

test('rejects a lookalike host that merely contains a supported name', () => {
  assert.equal(validateUrl('https://youtube.com.evil.tld/watch?v=1').ok, false);
});

test('accepts a genuine subdomain', () => {
  assert.equal(validateUrl('https://m.youtube.com/watch?v=1').ok, true);
});

test('rejects non-http schemes and junk', () => {
  for (const bad of ['file:///etc/passwd', 'ftp://youtube.com/x', 'javascript:alert(1)', '', '   ', null, 42]) {
    assert.equal(validateUrl(bad).ok, false, `expected ${String(bad)} to fail`);
  }
});

test('rejects control characters', () => {
  assert.equal(validateUrl('https://youtube.com/watch?v=a\nb').ok, false);
});

test('strips credentials and fragment', () => {
  const r = validateUrl('https://user:pw@youtube.com/watch?v=abc#frag');
  assert.equal(r.ok, true);
  assert.ok(!r.url.includes('user'));
  assert.ok(!r.url.includes('#frag'));
});

test('format validation', () => {
  assert.equal(validateFormat('mp4').format, 'mp4');
  assert.equal(validateFormat('MP3').format, 'mp3');
  assert.equal(validateFormat('wav').ok, false);
  assert.equal(validateFormat(undefined).ok, false);
});

test('quality validation defaults to best', () => {
  assert.equal(validateQuality(undefined).quality, 'best');
  assert.equal(validateQuality('720').quality, '720');
  assert.equal(validateQuality('4320').ok, false);
});

test('job id validation', () => {
  assert.equal(validateJobId('0123456789abcdef').ok, true);
  assert.equal(validateJobId('../../etc/passwd').ok, false);
  assert.equal(validateJobId('0123456789ABCDEF').ok, false);
  assert.equal(validateJobId('short').ok, false);
});

test('safeFilename strips path and reserved characters', () => {
  assert.equal(safeFilename('a/b\\c:d*e', 'mp4'), 'a b c d e.mp4');
  assert.equal(safeFilename('../../etc/passwd', 'mp3'), 'etc passwd.mp3');
  assert.equal(safeFilename('', 'mp4'), 'localizer.mp4');
  assert.equal(safeFilename('   ...   ', 'mp4'), 'localizer.mp4');
  assert.ok(safeFilename('x'.repeat(500), 'mp4').length <= 125);
});
